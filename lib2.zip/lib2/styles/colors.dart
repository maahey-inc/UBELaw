import 'package:flutter/material.dart';

final Color lprimaryColor = const Color(0xffEE4B45);
final Color lsecondaryColor = const Color(0xffFFAA00);
final Color lbasicDarkColor = const Color(0xff222B45);
final Color lbasicGreyColor = const Color(0xff8F9BB3);
final Color lbackgroundColor = const Color(0xffF7F9FC);

final Color dprimaryColor = const Color(0xffEE4B45);
final Color dsecondaryColor = const Color(0xffFFAA00);
final Color dbasicDarkColor = const Color(0xff222B45);
final Color dbasicGreyColor = const Color(0xff8F9BB3);
final Color dbackgroundColor = const Color(0xff222B45);

final Color facebookColor = const Color(0xff3B5998);
